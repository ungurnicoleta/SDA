#pragma once
#include "BinaryTree.h"
class Iterator 
{

public:
	BinaryTree tree{};
	Node* stack[255];
	int len = 0;
	Node* root;
	Node* current;
	Iterator(BinaryTree bt) : tree(bt)
	{
		current= tree.root;
		root = tree.root;
	}
	Node* getCurrent();
	bool isValid();
	void next(int param);
};