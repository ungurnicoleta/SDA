#pragma once
#include <string>
#include "Node.h"

class BinaryTree
{
public:
	Node* root = NULL;
	int size = 0;
	BinaryTree() {};
	~BinaryTree() {};
	bool isEmpty();

	Node* rootOfTree();
	Node* leftTree();
	Node* rightTree();

	Node* initLeaf(Node* node);
	Node* initTree(Node* left, Node* right);
	Node* initLeftSubree(Node* left);
	Node* initRightSubree(Node* right);

};