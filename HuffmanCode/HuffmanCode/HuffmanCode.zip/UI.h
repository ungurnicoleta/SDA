//#pragma once
//#include "PriorityQueue.h"
//
//class UI
//{
//private:
//	BinaryTree bt;
//public:
//	UI(const BinaryTree& bt) : bt(bt) {}
//
//	void run();
//
//private:
//	void printMenu();	
//	void encodeUI();
//	void decodeUI();
//};
//
