#include "BinaryTree.h"

bool BinaryTree:: isEmpty() {
	if (root->left == NULL && root->right == NULL)
		return true;
	return false;
}

Node* BinaryTree::rootOfTree()
{
	return root;
}

Node* BinaryTree::leftTree() 
{
	return root->left;
}

Node* BinaryTree::rightTree()
{
	return root->right;
}


Node* BinaryTree::initLeaf(Node* node)
{
	return root = node;
}

Node* BinaryTree::initTree(Node* left, Node* right)
{
	root->left = left;
	root->right = right;
	return root;
}

Node* BinaryTree::initLeftSubree(Node* left)
{
	root->left = left;
	return root;
}

Node* BinaryTree::initRightSubree(Node* right)
{
	root->right = right;
	return root;
}

